INSERT INTO `category` (`category_name`) VALUES
('Sport'),
('Tech'),
('Film'),
('Political'),
('Education'),
('Music'),
('Science');
